<script src="{{asset('public/dashboard-assets/vendors/core/core.js')}}"></script>
<!-- endinject -->
<!-- plugin js for this page -->
<script src="{{asset('public/dashboard-assets/vendors/chartjs/Chart.min.js')}}"></script>
<script src="{{asset('public/dashboard-assets/vendors/jquery.flot/jquery.flot.js')}}"></script>
<script src="{{asset('public/dashboard-assets/vendors/jquery.flot/jquery.flot.resize.js')}}"></script>
<script src="{{asset('public/dashboard-assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js')}}"></script>
<script src="{{asset('public/dashboard-assets/vendors/apexcharts/apexcharts.min.js')}}"></script>
<script src="{{asset('public/dashboard-assets/vendors/progressbar.js/progressbar.min.js')}}"></script>
<script src="{{asset('public/dashboard-assets/vendors/datatables/jquery.dataTables.js')}}"></script>
<script src="{{asset('public/dashboard-assets/vendors/datatables/dataTables.bootstrap4.js')}}"></script>
<!-- end plugin js for this page -->
<!-- inject:js -->
<script src="{{asset('public/dashboard-assets/vendors/feather-icons/feather.min.js')}}"></script>
<script src="{{asset('public/dashboard-assets/vendors/select2/select2.min.js')}}"></script>
<script src="{{asset('public/dashboard-assets/js/template.js')}}"></script>
<!-- endinject -->
<!-- custom js for this page -->
<script src="{{asset('public/dashboard-assets/js/dashboard.js')}}"></script>
<script src="{{asset('public/dashboard-assets/js/datepicker.js')}}"></script>
<!-- end custom js for this page -->
{{-- Form Repeater --}}
<script src="{{asset('public/js/repeater/jquery.repeater.min.js')}}"></script>
<script src="{{asset('public/js/jquery.form-repeater.js')}}"></script>
