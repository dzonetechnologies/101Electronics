<footer class="footer d-flex flex-column align-items-center justify-content-between">
    <p class="text-muted text-center text-md-left">
        Copyright © {{date("Y")}} <a href="javascript:void(0);" target="_blank">101 Electronics</a>. All rights reserved
    </p>
</footer>
